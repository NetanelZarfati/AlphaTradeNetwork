from utils.config_loader import load_config, load_settings
from utils.logger import log_info, log_error
from utils.telegram_notifier import send_trade_signal
from utils.verify_structure import verify_project_structure
from data.ohlc_downloader import download_ohlc_batch
from analyzers.symbol_analyzer import analyze_symbol
from analyzers.market_analyzer import analyze_market
from executors.gpt_decider import decide_action

def main():
    log_info("🚀 AlphaTradeA starting...")

    # בדיקת תקינות מבנה מערכת
    verify_project_structure()

    # טענת הגדרות וסמלים
    config = load_config()
    settings = load_settings()
    symbols = settings.get("symbols_to_monitor", [])
    if not symbols:
        log_error("No symbols found in settings.")
        return

    log_info(f"Loaded symbols: {symbols}")

    # הורדת נתוני OHLC
    download_ohlc_batch(symbols)
    log_info("Completed OHLC data fetch.")

    # ניתוח שוק כללי
    market_data = analyze_market()
    log_info(f"Market data: {market_data}")

    # מעבר על כל סימבול
    for symbol in symbols:
        analysis = analyze_symbol(symbol)
        log_info(f"Analysis for {symbol}: {analysis}")

        # קבלת החלטה מהמודל
        action, confidence, reason = decide_action(market_data | analysis)
                send_trade_signal(action, confidence, reason)
        log_info(f"GPT Decision [{symbol}]: {action} ({confidence}%) – {reason}")

        # TODO: כתיבת פקודת פעולה לרובוט (JSON)

    log_info("✅ AlphaTradeA finished execution.")

if __name__ == "__main__":
    main()