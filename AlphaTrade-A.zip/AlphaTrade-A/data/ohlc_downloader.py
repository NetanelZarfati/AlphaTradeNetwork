"""
OHLC Downloader – Unified into system
Source: TwelveData API
"""

import os
import json
import csv
import requests
from datetime import datetime
from pathlib import Path

# Load API key from standard config
CONFIG_PATH = Path(__file__).resolve().parent.parent / "configs" / "api_keys.json"
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    API_KEYS = json.load(f)

API_KEY = API_KEYS.get("twelvedata")
BASE_DIR = Path(__file__).resolve().parent

def download_ohlc(symbol, interval="1h", output_size=100):
    url = f"https://api.twelvedata.com/time_series?symbol={symbol}&interval={interval}&outputsize={output_size}&apikey={API_KEY}&format=JSON"
    response = requests.get(url, timeout=10)
    data = response.json()

    if "values" not in data:
        print(f"[ERROR] Failed to fetch OHLC for {symbol}: {data.get('message', 'No data')}")
        return

    values = data["values"]
    values.reverse()  # oldest first

    BASE_DIR.mkdir(parents=True, exist_ok=True)
    file_path = BASE_DIR / f"{symbol}_ohlc.csv"

    with open(file_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp", "open", "high", "low", "close", "volume"])
        for row in values:
            writer.writerow([
                row["datetime"],
                row["open"],
                row["high"],
                row["low"],
                row["close"],
                row["volume"]
            ])

    print(f"[INFO] OHLC data saved: {file_path}")

def download_ohlc_batch(symbols, interval="1h"):
    for sym in symbols:
        download_ohlc(sym, interval=interval)

if __name__ == "__main__":
    symbols = ["AAPL", "MSFT", "GOOG"]
    download_ohlc_batch(symbols)
