"""
AlphaTrade - API Keys Configuration File
שימו לב: שמרו קובץ זה במקום מאובטח
"""

API_KEYS = {
    "newsapi": "91b747eb1d244f0587f4823ba7d3af86",
    "twelvedata": "b3d6a92f779749fb91b78b72b9da5650",
    "finnhub": "d0vbmq9r01qmg3ulfj5gd0vbmq9r01qmg3ulfj60",
    "alpha_vantage": "U06NMWMFG7ADKRT3",
    "marketstack": "78c9dbdcaa66e3a622463512081bf4bd",
    "tradingview_rapid": "826037e2d7mshda0c32858fde066p1a9bf2jsnaf24616d8bc7"
}



OpenAI

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