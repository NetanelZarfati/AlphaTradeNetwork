
# AlphaTrade-A – מערכת מסחר חכמה

גרסה סופית, יציבה ומודולרית של מערכת AlphaTrade-A. המערכת מבוססת Python ומיועדת לשילוב עם MetaTrader 4.

---

## 🧠 רכיבי המערכת

| תיקייה            | תפקיד |
|-------------------|--------|
| `core/`           | קובץ `main.py` שמריץ את המערכת |
| `utils/`          | פונקציות עזר, כולל בדיקות, טעינת config, לוגים ו־API |
| `configs/`        | קבצי תצורה כולל `api_keys.json`, `settings.json` |
| `data/`           | קובצי OHLC שנמשכים מה־API |
| `signals/`        | תוצרי החלטות מסחר |
| `command_files/`  | קבצי הוראות לרובוט (ל־MT4) |
| `logs/`           | קובצי לוג כולל בדיקת תקינות |
| `robot_sources/`  | קבצי MQ4 של הרובוט MetaTrader |
| `analyzers/`      | ניתוח שוק וסימבולים |
| `executors/`      | הפעלת החלטות מסחר |
| `meta/`           | קובץ `version.txt` עם גרסה |

---

## ⚙️ תהליך הרצה עיקרי

1. המערכת מתחילה עם `core/main.py`
2. מתבצעת בדיקת תקינות דרך `verify_structure.py`
3. נטענים הסימבולים מתוך `configs/settings.json`
4. נמשכים נתוני OHLC דרך TwelveData → `data/*.csv`
5. המידע נשלח להחלטת GPT ו־API נוספים
6. נכתבים קבצי `signals/*.csv` ו־`command_files/*.json`

---

## 🔑 קובצי קונפיג חשובים

### `configs/settings.json`
```json
{
  "log_level": "info",
  "max_api_calls_per_day": 1000,
  "symbols_to_monitor": ["AAPL", "MSFT", "GOOG"]
}
```

### `configs/api_keys.json`
```json
{
  "finnhub": "xxxx",
  "twelvedata": "xxxx",
  "alphavantage": "xxxx",
  "tradingview": "xxxx"
}
```

---

## 📊 תיעוד לוגים

- `logs/startup_check.log` – תיעוד תקינות המערכת
- לוגים נוספים נוצרים לפי צורך בתיקייה `logs/`

---

## ✅ דרישות להפעלה

- Python 3.9+
- חבילת `requests`
- קבצי API ותצורה תקינים

---

## 📥 קלט / 📤 פלט

- **קלט:** `data/*.csv`, `settings.json`
- **פלט:** `signals/*.csv`, `command_files/*.json`

---

## 🧪 בדיקת תקינות

נעשית אוטומטית דרך:
```python
from utils.verify_structure import verify_project_structure
```

בודקת:
- קיום תיקיות
- תקינות קבצי JSON
- מפתחות API
- סמלים

---

## 📝 גרסה נוכחית
נמצאת בקובץ: `meta/version.txt`

---

© 2025 AlphaTrade™ | מערכת מסחר מתקדמת
