def load_csv(path):
    """טוען קובץ CSV ומחזיר רשימה של מילונים."""
    with suppress(Exception):
        with path.open("r", encoding="utf-8") as f:
            return list(csv.DictReader(f, delimiter=";"))
    print(f"[ERROR] Failed to read CSV: {path}")
    return []

def there_is_red_news_next_30_minutes():
    """בודק האם יש חדשות כלכליות קרובות עם השפעה גבוהה ב-30 הדקות הקרובות."""
    try:
        if not check_internet():
            return False
        url = "https://www.forexfactory.com/calendar"
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        now = datetime.utcnow()
        rows = soup.select("tr.calendar__row")
        for row in rows:
            time_cell = row.select_one(".calendar__time")
            currency_cell = row.select_one(".calendar__currency")
            impact_cell = row.select_one(".impact--high")
            if not (time_cell and currency_cell and impact_cell):
                continue
            if currency_cell.get_text(strip=True) != "USD":
                continue
            time_text = time_cell.get_text(strip=True)
            if time_text.lower() in ["all day", "tentative", ""]:
                continue
            try:
                event_time = datetime.strptime(time_text, "%H:%M")
                event_time = now.replace(hour=event_time.hour, minute=event_time.minute, second=0, microsecond=0)
                if 0 <= (event_time - now).total_seconds() <= 1800:
                    return True
            except ValueError:
                continue
        return False
    except:
        return False

def detect_symbols_from_files():
    """מאתר סימבולים מתוך קבצי OHLC בתיקיית MT4."""
    try:
        return [
            f.replace("_ohlc.csv", "")
            for f in os.listdir(MT4_FILES_DIR)
            if f.endswith("_ohlc.csv")
        ]
    except Exception as e:
        print(f"[ERROR] Failed to detect symbols: {e}")
        return []

def get_ohlc_closes(symbol):
    """מקבל רשימת מחירי סגירה מתוך קובץ OHLC עבור סימבול מסוים."""
    try:
        with open(MT4_FILES_DIR / f"{symbol}_ohlc.csv", newline='') as f:
            reader = csv.DictReader(f, delimiter=';')
            closes = [float(row['close']) for row in reader][-30:]
        return closes
    except Exception as e:
        print(f"[{symbol}] ERROR reading OHLC CSV: {e}")
        return []

def is_allowed_time():
    """בודק האם השעה הנוכחית מותרת לניתוח."""
    return True

def is_locked():
    """בודק האם המערכת נעולה."""
    return (MT4_FILES_DIR / "lock.txt").exists()

def is_paused():
    """בודק האם המערכת בהשהיה."""
    return (MT4_FILES_DIR / "pause.txt").exists()

def there_is_red_news_next_30_minutes():
    try:
        import requests
        from bs4 import BeautifulSoup
        from datetime import datetime
        url = "https://www.forexfactory.com/calendar"
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        now = datetime.utcnow()
        rows = soup.select("tr.calendar__row")
        for row in rows:
            time_cell = row.select_one(".calendar__time")
            currency_cell = row.select_one(".calendar__currency")
            impact_cell = row.select_one(".impact--high")
            if not (time_cell and currency_cell and impact_cell):
                continue
            if currency_cell.get_text(strip=True) != "USD":
                continue
            time_text = time_cell.get_text(strip=True)
            if time_text.lower() in ["all day", "tentative", ""]:
                continue
            try:
                event_time = datetime.strptime(time_text, "%H:%M")
                event_time = now.replace(hour=event_time.hour, minute=event_time.minute, second=0, microsecond=0)
                if 0 <= (event_time - now).total_seconds() <= 1800:
                    return True
            except ValueError:
                continue
        return False
    except:
        return False