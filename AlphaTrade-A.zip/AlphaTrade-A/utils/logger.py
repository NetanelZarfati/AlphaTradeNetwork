from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

def _get_log_file():
    today = datetime.now().strftime("log_%Y-%m-%d.txt")
    return LOG_DIR / today

def _write_log(level, message):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted = f"[{ts}] [{level.upper()}] {message}"
    print(formatted)
    with open(_get_log_file(), "a", encoding="utf-8") as f:
        f.write(formatted + "\n")

def log_info(message):
    _write_log("INFO", message)

def log_error(message):
    _write_log("ERROR", message)

def log_debug(message):
    _write_log("DEBUG", message)