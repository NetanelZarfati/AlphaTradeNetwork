"""
Module: apis.py
Purpose: Unified API-based technical summary fetcher (no scraping)
"""

import requests
import json
import os

# Load API keys from external JSON file
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "configs", "api_keys.json")
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    API_KEYS = json.load(f)

def get_technical_summary_from_api(symbol: str) -> dict:
    """
    Attempts to retrieve a technical summary for a symbol from multiple APIs.
    Priority order: Finnhub -> TwelveData -> TradingView -> AlphaVantage
    """
    result = {
        "summary": "UNKNOWN",
        "rsi": None,
        "macd": None
    }

    # Finnhub
    try:
        r = requests.get(
            f"https://finnhub.io/api/v1/scan/technical-indicator?symbol={symbol}&resolution=D&token={API_KEYS['finnhub']}"
        )
        if r.ok:
            data = r.json()
            result["summary"] = data.get("technicalAnalysis", {}).get("signal", "UNKNOWN").upper()
            return result
    except Exception as e:
        print(f"[API] Finnhub failed: {e}")

    # TwelveData
    try:
        r = requests.get(
            f"https://api.twelvedata.com/technical_summary?symbol={symbol}&interval=1day&apikey={API_KEYS['twelvedata']}"
        )
        if r.ok:
            data = r.json()
            summary = data.get("technical_summary", {}).get("recommendation")
            if summary:
                result["summary"] = summary.upper()
                return result
    except Exception as e:
        print(f"[API] TwelveData failed: {e}")

    # TradingView (via RapidAPI)
    try:
        headers = {
            "X-RapidAPI-Key": API_KEYS["tradingview"],
            "X-RapidAPI-Host": "trading-view.p.rapidapi.com"
        }
        r = requests.get(
            f"https://trading-view.p.rapidapi.com/summary/?symbol={symbol}&region=US",
            headers=headers
        )
        if r.ok:
            data = r.json()
            summary = data.get("summary", {}).get("RECOMMENDATION")
            if summary:
                result["summary"] = summary.upper()
                return result
    except Exception as e:
        print(f"[API] TradingView failed: {e}")

    # Alpha Vantage
    try:
        r = requests.get(
            f"https://www.alphavantage.co/query?function=RSI&symbol={symbol}&interval=daily&time_period=14&series_type=close&apikey={API_KEYS['alphavantage']}"
        )
        if r.ok:
            data = r.json()
            technicals = list(data.get("Technical Analysis: RSI", {}).values())
            if technicals:
                rsi_val = float(technicals[-1]["RSI"])
                result["rsi"] = rsi_val
                result["summary"] = "BUY" if rsi_val < 30 else "SELL" if rsi_val > 70 else "NEUTRAL"
                return result
    except Exception as e:
        print(f"[API] AlphaVantage failed: {e}")

    return result
