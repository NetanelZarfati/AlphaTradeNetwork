import os
import json
from pathlib import Path
from datetime import datetime

def verify_project_structure():
    base = Path(__file__).resolve().parent.parent
    logs = base / "logs"
    log_file = logs / "startup_check.log"
    logs.mkdir(exist_ok=True)

    def log(message):
        print(message)
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now()} | {message}\n")

    log("🔍 Starting AlphaTrade structure verification...")

    # 1. Check required folders
    required_dirs = ["configs", "data", "signals", "logs", "meta", "executors", "analyzers", "core"]
    for folder in required_dirs:
        path = base / folder
        if not path.exists():
            log(f"[ERROR] Missing folder: {folder}")
        else:
            log(f"[OK] Folder exists: {folder}")

    # 2. Check required config files
    config_files = [
        ("configs/config.json", True),
        ("configs/api_keys.json", True),
        ("configs/settings.json", True),
        ("configs/config_api_keys.py", False),
        ("configs/paths.json", True)
    ]
    for rel_path, should_be_json in config_files:
        path = base / rel_path
        if not path.exists():
            log(f"[WARNING] Missing file: {rel_path}")
            continue
        log(f"[OK] Found: {rel_path}")
        if should_be_json:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    json.load(f)
                log(f"[OK] Valid JSON: {rel_path}")
            except Exception as e:
                log(f"[ERROR] Invalid JSON in {rel_path}: {e}")

    # 3. Validate API keys
    try:
        with open(base / "configs" / "api_keys.json", "r", encoding="utf-8") as f:
            keys = json.load(f)
        required_keys = ["finnhub", "twelvedata", "alpha_vantage", "marketstack", "newsapi"]
        for k in required_keys:
            if not keys.get(k):
                log(f"[ERROR] Missing or empty API key: {k}")
            else:
                log(f"[OK] API key exists: {k}")
    except Exception as e:
        log(f"[ERROR] Failed to validate api_keys.json: {e}")

    # 4. Validate openai_key
    try:
        with open(base / "configs" / "config.json", "r", encoding="utf-8") as f:
            cfg = json.load(f)
        if not cfg.get("openai_key"):
            log("[ERROR] Missing or empty openai_key in config.json")
        else:
            log("[OK] Found OpenAI key in config.json")
    except Exception as e:
        log(f"[ERROR] Failed to parse config.json: {e}")

    # 5. Validate call_counter.json
    try:
        with open(base / "configs" / "call_counter.json", "r", encoding="utf-8") as f:
            counter = json.load(f)
        if "date" not in counter or "count" not in counter:
            log("[ERROR] Invalid structure in call_counter.json")
        else:
            log("[OK] call_counter.json structure is valid")
    except Exception as e:
        log(f"[WARNING] call_counter.json missing or invalid: {e}")

    # 6. Validate version file
    version_path = base / "meta" / "version.txt"
    if version_path.exists():
        version = version_path.read_text(encoding="utf-8").strip()
        log(f"[OK] Version file found: {version}")
    else:
        log("[WARNING] meta/version.txt not found")

    # 7. Check log write permission
    try:
        test_path = logs / "temp_test.log"
        with open(test_path, "w") as f:
            f.write("test")
        test_path.unlink()
        log("[OK] Log directory is writable")
    except Exception as e:
        log(f"[ERROR] Cannot write to log directory: {e}")

    log("✅ Structure verification completed.")