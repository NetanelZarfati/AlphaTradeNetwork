import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def load_json_config(filename):
    path = BASE_DIR / "configs" / filename
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[ERROR] Failed to load {filename}: {e}")
        return {}

def load_config():
    return load_json_config("config.json")

def load_settings():
    return load_json_config("settings.json")

def load_api_keys():
    return load_json_config("api_keys.json")

def load_paths():
    return load_json_config("paths.json") if (BASE_DIR / "configs/paths.json").exists() else {}

def get_api_key(name):
    return load_api_keys().get(name)

def get_path(key):
    return load_paths().get(key)