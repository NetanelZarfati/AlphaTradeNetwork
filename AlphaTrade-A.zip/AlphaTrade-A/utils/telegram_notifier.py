
import json
from pathlib import Path
from datetime import datetime
import telegram

# טוען את המפתחות מקובץ configs/api_keys.json
def load_telegram_config():
    config_path = Path(__file__).resolve().parent.parent / "configs" / "api_keys.json"
    with open(config_path, "r", encoding="utf-8") as f:
        keys = json.load(f)
    return keys.get("telegram_token"), keys.get("telegram_user_id")

# פונקציה כללית לשליחת הודעת טלגרם
def send_telegram(message: str):
    try:
        token, user_id = load_telegram_config()
        if not token or not user_id:
            print("[WARNING] Missing Telegram credentials.")
            return
        bot = telegram.Bot(token=token)
        bot.send_message(chat_id=user_id, text=message)
    except Exception as e:
        print(f"[ERROR] Failed to send Telegram message: {e}")
# פונקציה לשליחת הודעת המלצת מסחר מעוצבת
def send_trade_signal(action, confidence, reason):
    try:
        token, user_id = load_telegram_config()
        if not token or not user_id:
            print("[WARNING] Missing Telegram credentials.")
            return
        bot = telegram.Bot(token=token)
        now = datetime.now().strftime("%H:%M")
        action_he = {
            "BUY": "קנייה 📈",
            "SELL": "מכירה 📉",
            "WAIT": "המתנה ⏳"
        }.get(action.upper(), action.upper())
        msg = (
            f"🤖 המלצת בינה למסחר:

"
            f"📌 פעולה: {action_he}
"
            f"🔐 ביטחון: {confidence}%
"
            f"📊 נימוק: {reason}
"
            f"🕒 שעה: {now}"
        )
        bot.send_message(chat_id=user_id, text=msg)
    except Exception as e:
        print(f"[ERROR] Failed to send trade signal: {e}")