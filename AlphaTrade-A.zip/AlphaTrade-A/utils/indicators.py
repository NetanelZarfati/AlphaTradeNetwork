def calculate_rsi(closes, period=14):
    """מחשב את ערך ה-RSI עבור רשימת מחירים סגירה."""
    if len(closes) < period + 1:
        return 50
    deltas = np.diff(closes[-(period+1):])
    ups = deltas[deltas > 0].sum() / period
    downs = abs(deltas[deltas < 0].sum()) / period
    rs = ups / downs if downs != 0 else 1
    return round(100 - (100 / (1 + rs)), 2)

    def detect_spike(closes):
        """זיהוי קפיצה במחירים."""
        if len(closes) < 5:
            return False
        recent_std = np.std(closes[-5:])
        last_move = abs(closes[-1] - closes[-2])
        return last_move > 1.5 * recent_std

    def detect_pin_bar(closes):
        """בודק האם יש תבנית Pin Bar ברשימת מחירים סגירה."""
        if len(closes) < 2:
            return False
        body = abs(closes[-1] - closes[-2])
        range_candle = max(closes[-1], closes[-2]) - min(closes[-1], closes[-2])
        if range_candle == 0:
            return False
        return body / range_candle < 0.25

    # טעינת או יצירת פרופיל הצלחה
    success_profile_path = MT4_FILES_DIR / f"success_profile_{symbol}.json"
    if not success_profile_path.exists():
        default_profile = {"confidence_multiplier": 1.0, "min_confidence": 65}
        success_profile_path.write_text(json.dumps(default_profile, indent=2))

    try:
        with success_profile_path.open("r", encoding="utf-8") as f:
            success_profile = json.load(f)
    except Exception as e:
        print(f"[WARNING] Failed to load success profile for {symbol}: {e}")
        success_profile = {"confidence_multiplier": 1.0, "min_confidence": 65}

    paths = {
        "ohlc": MT4_FILES_DIR / f"{symbol}_ohlc.csv",
        "profile": MT4_FILES_DIR / f"success_profile_{symbol}.json",
        "reverse": MT4_FILES_DIR / "reverse_mode.txt",
        "lock": MT4_FILES_DIR / "lock.txt",
        "pause": MT4_FILES_DIR / "pause.txt",
        "recommendation": SIGNALS_DIR / f"{symbol}_recommendation.csv",
        "command": SIGNALS_DIR / f"{symbol}_command.csv"
    }

    if paths["pause"].exists() or paths["lock"].exists():
        print(f"[INFO] {symbol} skipped due to PAUSE/LOCK")
        return

    rows = load_csv(paths["ohlc"])[-20:]
    if len(rows) < 14:
        print(f"[ERROR] Not enough data for {symbol}")
        return

    closes = [float(r["close"]) for r in rows]
    rsi = calculate_rsi(closes)
    trend = (closes[-1] - closes[0]) / closes[0]
    macd = closes[-1] - mean(closes[-12:])
    spike = detect_spike(closes)

    try:
        prompt = f"Symbol: {symbol}\nRSI: {rsi:.2f}\nMACD: {macd:.4f}\nTrend: {trend:.4f}\nSpike: {spike}\nGive decision: BUY or SELL only"
        gpt_response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=10
        )
        decision = gpt_response.choices[0].message['content'].strip().upper()
    except Exception as e:
        print(f"[GPT] Error: {e}")
        decision = "WAIT"

    try:
        try:
            tech = get_technical_summary_from_api(symbol)
            online_signal = tech.get("summary", "UNKNOWN")
        except Exception as e:
            print(f"[{symbol}] ❌ API error: {e}")
            online_signal = "UNKNOWN"
        base_conf = (rsi - 50) + (trend * 100) + (macd * 100) + (10 if spike else 0)
        if online_signal and online_signal in ["STRONG BUY", "STRONG SELL"]:
            base_conf += 5
        elif online_signal and online_signal == "NEUTRAL":
            base_conf -= 5
        news_impact = load_news_impact(symbol)
        base_conf += news_impact
        confidence = int(min(100, max(0, base_conf * success_profile.get("confidence_multiplier", 1.0))))
        if online_signal:
            print(f"[{symbol}] Online Signal: {online_signal}")
    except Exception as e:
        print(f"[Scraper] Error integrating online signal for {symbol}: {e}")

    if paths["reverse"].exists() and decision in ["BUY", "SELL"]:
        decision = "BUY" if decision == "SELL" else "SELL"

    if confidence < success_profile.get("min_confidence", 65):
        print(f"[INFO] {symbol} filtered out due to low confidence: {confidence}")
        return

    volatility = stdev(closes)
    adaptive_tp = round(volatility * 2, 1)
    adaptive_sl = round(volatility * 1.5, 1)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    avg_range, std_range = calculate_range_metrics(closes)
    pinbar = detect_pin_bar(closes)

    print(f"[{symbol}] {decision} | CONF={confidence} | RSI={rsi:.2f} | MACD={macd:.4f} | TREND={trend:.4f} | SPIKE={spike} | AVG_RANGE={avg_range:.2f} | STD_RANGE={std_range:.2f}")

    with paths["recommendation"].open("w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["symbol", "decision", "confidence", "tp", "sl", "lot", "comment", "time"])
        writer.writerow([symbol, decision, confidence, adaptive_tp, adaptive_sl, config["default_lot"], "alpha_v3", now])

    with paths["command"].open("w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["symbol", "action", "tp", "sl", "lot", "magic", "time"])
        writer.writerow([symbol, decision, adaptive_tp, adaptive_sl, config["default_lot"], 10000, now])

    with open(DEBUG_CSV_PATH, "a", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["symbol", "decision", "rsi", "macd", "trend", "spike", "confidence", "time", "pinbar", "online_signal"])
        writer.writerow([symbol, decision, rsi, macd, trend, spike, confidence, now, pinbar, online_signal])

    with open(BADGES_CSV_PATH, "a", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["symbol", "badge", "confidence", "time"])
        badge = "GOLD" if confidence >= 85 else "SILVER" if confidence >= 70 else "BRONZE"
        writer.writerow([symbol, badge, confidence, now])

    with open(BATCH_PATH, "a", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["symbol", "decision", "confidence", "tp", "sl", "time"])
        writer.writerow([symbol, decision, confidence, adaptive_tp, adaptive_sl, now])

    with open(STATUS_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump({
            "symbol": symbol,
            "decision": decision,
            "confidence": confidence,
            "rsi": rsi,
            "macd": macd,
            "trend": trend,
            "spike": str(spike),
            "time": now
        }, f, indent=4)

    send_telegram_message(decision, confidence, f"RSI: {rsi}, MACD: {macd}, Trend: {trend}, Spike: {spike}")

def calculate_trend(prices):
    """מחשב את המגמה של רשימת מחירים."""
    if len(prices) < 2:
        return 0
    x = np.arange(len(prices))
    slope, _ = np.polyfit(x, prices, 1)
    return round(slope, 4)

def detect_spike(prices, threshold=10):
    """מאתר קפיצה במחירים על פי סף נתון."""
    diffs = [abs(prices[i] - prices[i - 1]) for i in range(1, len(prices))]
    return "yes" if max(diffs) > threshold else "no"

