def analyze_symbol(symbol):
    """מנתח סימבול מסוים ומבצע החלטות מסחר על סמך הנתונים."""
    def calculate_range_metrics(closes):
        """חישוב ממוצע וטווח סטיית תקן של מחירים."""
        if len(closes) < 2:
            return 0, 0
        bodies = [abs(closes[i] - closes[i - 1]) for i in range(1, len(closes))]
        avg_range = mean(bodies)
        std_range = stdev(bodies) if len(bodies) > 1 else 0
        return avg_range, std_range

    def detect_spike(closes):
        """זיהוי קפיצה במחירים."""
        if len(closes) < 5:
            return False
        recent_std = np.std(closes[-5:])
        last_move = abs(closes[-1] - closes[-2])
        return last_move > 1.5 * recent_std

    def detect_pin_bar(closes):
        """בודק האם יש תבנית Pin Bar ברשימת מחירים סגירה."""
        if len(closes) < 2:
            return False
        body = abs(closes[-1] - closes[-2])
        range_candle = max(closes[-1], closes[-2]) - min(closes[-1], closes[-2])
        if range_candle == 0:
            return False
        return body / range_candle < 0.25

    # טעינת או יצירת פרופיל הצלחה
    success_profile_path = MT4_FILES_DIR / f"success_profile_{symbol}.json"
    if not success_profile_path.exists():
        default_profile = {"confidence_multiplier": 1.0, "min_confidence": 65}
        success_profile_path.write_text(json.dumps(default_profile, indent=2))

    try:
        with success_profile_path.open("r", encoding="utf-8") as f:
            success_profile = json.load(f)
    except Exception as e:
        print(f"[WARNING] Failed to load success profile for {symbol}: {e}")
        success_profile = {"confidence_multiplier": 1.0, "min_confidence": 65}

    paths = {
        "ohlc": MT4_FILES_DIR / f"{symbol}_ohlc.csv",
        "profile": MT4_FILES_DIR / f"success_profile_{symbol}.json",
        "reverse": MT4_FILES_DIR / "reverse_mode.txt",
        "lock": MT4_FILES_DIR / "lock.txt",
        "pause": MT4_FILES_DIR / "pause.txt",
        "recommendation": SIGNALS_DIR / f"{symbol}_recommendation.csv",
        "command": SIGNALS_DIR / f"{symbol}_command.csv"
    }

    if paths["pause"].exists() or paths["lock"].exists():
        print(f"[INFO] {symbol} skipped due to PAUSE/LOCK")
        return

    rows = load_csv(paths["ohlc"])[-20:]
    if len(rows) < 14:
        print(f"[ERROR] Not enough data for {symbol}")
        return

    closes = [float(r["close"]) for r in rows]
    rsi = calculate_rsi(closes)
    trend = (closes[-1] - closes[0]) / closes[0]
    macd = closes[-1] - mean(closes[-12:])
    spike = detect_spike(closes)

    try:
        prompt = f"Symbol: {symbol}\nRSI: {rsi:.2f}\nMACD: {macd:.4f}\nTrend: {trend:.4f}\nSpike: {spike}\nGive decision: BUY or SELL only"
        gpt_response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=10
        )
        decision = gpt_response.choices[0].message['content'].strip().upper()
    except Exception as e:
        print(f"[GPT] Error: {e}")
        decision = "WAIT"

    try:
        try:
            tech = get_technical_summary_from_api(symbol)
            online_signal = tech.get("summary", "UNKNOWN")
        except Exception as e:
            print(f"[{symbol}] ❌ API error: {e}")
            online_signal = "UNKNOWN"
        base_conf = (rsi - 50) + (trend * 100) + (macd * 100) + (10 if spike else 0)
        if online_signal and online_signal in ["STRONG BUY", "STRONG SELL"]:
            base_conf += 5
        elif online_signal and online_signal == "NEUTRAL":
            base_conf -= 5
        news_impact = load_news_impact(symbol)
        base_conf += news_impact
        confidence = int(min(100, max(0, base_conf * success_profile.get("confidence_multiplier", 1.0))))
        if online_signal:
            print(f"[{symbol}] Online Signal: {online_signal}")
    except Exception as e:
        print(f"[Scraper] Error integrating online signal for {symbol}: {e}")

    if paths["reverse"].exists() and decision in ["BUY", "SELL"]:
        decision = "BUY" if decision == "SELL" else "SELL"

    if confidence < success_profile.get("min_confidence", 65):
        print(f"[INFO] {symbol} filtered out due to low confidence: {confidence}")
        return

    volatility = stdev(closes)
    adaptive_tp = round(volatility * 2, 1)
    adaptive_sl = round(volatility * 1.5, 1)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    avg_range, std_range = calculate_range_metrics(closes)
    pinbar = detect_pin_bar(closes)

    print(f"[{symbol}] {decision} | CONF={confidence} | RSI={rsi:.2f} | MACD={macd:.4f} | TREND={trend:.4f} | SPIKE={spike} | AVG_RANGE={avg_range:.2f} | STD_RANGE={std_range:.2f}")

    with paths["recommendation"].open("w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["symbol", "decision", "confidence", "tp", "sl", "lot", "comment", "time"])
        writer.writerow([symbol, decision, confidence, adaptive_tp, adaptive_sl, config["default_lot"], "alpha_v3", now])

    with paths["command"].open("w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["symbol", "action", "tp", "sl", "lot", "magic", "time"])
        writer.writerow([symbol, decision, adaptive_tp, adaptive_sl, config["default_lot"], 10000, now])

    with open(DEBUG_CSV_PATH, "a", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["symbol", "decision", "rsi", "macd", "trend", "spike", "confidence", "time", "pinbar", "online_signal"])
        writer.writerow([symbol, decision, rsi, macd, trend, spike, confidence, now, pinbar, online_signal])

    with open(BADGES_CSV_PATH, "a", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["symbol", "badge", "confidence", "time"])
        badge = "GOLD" if confidence >= 85 else "SILVER" if confidence >= 70 else "BRONZE"
        writer.writerow([symbol, badge, confidence, now])

    with open(BATCH_PATH, "a", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        if f.tell() == 0:
            writer.writerow(["symbol", "decision", "confidence", "tp", "sl", "time"])
        writer.writerow([symbol, decision, confidence, adaptive_tp, adaptive_sl, now])

    with open(STATUS_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump({
            "symbol": symbol,
            "decision": decision,
            "confidence": confidence,
            "rsi": rsi,
            "macd": macd,
            "trend": trend,
            "spike": str(spike),
            "time": now
        }, f, indent=4)

    send_telegram_message(decision, confidence, f"RSI: {rsi}, MACD: {macd}, Trend: {trend}, Spike: {spike}")

def update_success_profile(symbol):
    """עדכון פרופיל הצלחה על בסיס ביצועים קודמים."""
    profile_path = MT4_FILES_DIR / f"success_profile_{symbol}.json"
    if not DEBUG_CSV_PATH.exists():
        return

    try:
        with DEBUG_CSV_PATH.open("r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    except Exception as e:
        print(f"[LEARNING] Failed to read debug.csv: {e}")
        return

    recent = [r for r in rows if r["symbol"] == symbol and r["decision"] in ("BUY", "SELL")]
    if len(recent) < 10:
        return

    last_20 = recent[-20:]
    successful = [r for r in last_20 if float(r["confidence"]) >= 70]
    ratio = len(successful) / len(last_20)

    multiplier = 1.0 + (ratio - 0.5)
    min_conf = 60 if ratio > 0.6 else 70

    updated = {
        "confidence_multiplier": round(multiplier, 2),
        "min_confidence": min_conf
    }

    try:
        with profile_path.open("w", encoding="utf-8") as f:
            json.dump(updated, f, indent=2)
        print(f"[LEARNING] Updated success profile for {symbol}: {updated}")
    except Exception as e:
        print(f"[LEARNING] Failed to update profile for {symbol}: {e}")

def save_debug(symbol, data, decision):
    """שומר נתוני דיבוג עבור סימבול מסוים."""
    try:
        file_path = SIGNALS_DIR / f"debug_{symbol}.csv"
        file_exists = file_path.exists()
        with open(file_path, "a", newline='') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(["datetime", "rsi", "trend", "spike", "decision"])
            writer.writerow([datetime.now(), data['rsi'], data['trend'], data['spike'], decision])
        print(f"[{symbol}] ✔ Debug saved to {file_path}")
    except Exception as e:
        print(f"[{symbol}] ❌ Failed to save debug: {e}")

def analyze_symbol_fury(symbol):
    """מנתח סימבול מסוים במערכת FuryMind."""
    print(f"--- Analyzing {symbol} ---")
    if not is_allowed_time():
        print(f"[{symbol}] ❌ Outside allowed analysis hours")
        return
    if is_paused() or is_locked():
        print(f"[{symbol}] ❌ Paused or Locked")
        return

    prices = get_ohlc_closes(symbol)
    if len(prices) < 15:
        print(f"[{symbol}] ❌ Not enough price data (need 15+ closes)")
        return

    rsi = calculate_rsi(prices)
    trend = calculate_trend(prices)
    spike = detect_spike(prices)

    data = {
        "rsi": rsi,
        "trend": trend,
        "spike": str(spike)
    }

    profile = None
    try:
        with open(MT4_FILES_DIR / f"success_profile_{symbol}.json") as f:
            profile = json.load(f)
    except:
        pass

    prompt = build_prompt(data, profile)
    print(f"[{symbol}] Prompt => {prompt}")
    decision = query_gpt(prompt)
    reverse = is_reverse()
    decision_final = "sell" if decision == "buy" and reverse else decision

    save_log(symbol, f"RSI={rsi} TREND={trend} SPIKE={spike} DECISION={decision_final}")
    save_debug(symbol, data, decision_final)

    if decision_final not in ["buy", "sell"]:
        print(f"[{symbol}] No valid decision made.")
        return

    # Save decision and send to Telegram