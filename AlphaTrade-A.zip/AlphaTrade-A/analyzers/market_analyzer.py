def analyze_market():
    """מנתח את השוק ומחזיר נתונים טכניים על סמך אתר Investing."""
    try:
        url = "https://www.investing.com/indices/us-30-technical"
        headers = {"User-Agent": "Mozilla/5.0"}
        page = requests.get(url, headers=headers)
        soup = BeautifulSoup(page.content, "html.parser")

        summary_table = soup.find("table", class_="technicalSummaryTbl")
        summary_5m = summary_15m = "NEUTRAL"
        if summary_table:
            rows = summary_table.find_all("tr")
            for row in rows[1:]:
                cols = row.find_all("td")
                if len(cols) >= 2:
                    tf = cols[0].text.strip().lower()
                    rec = cols[1].text.strip().upper()
                    if "5 minutes" in tf:
                        summary_5m = rec
                    elif "15 minutes" in tf:
                        summary_15m = rec

        indicator_table = soup.find("table", class_="overviewSummaryTbl")
        buy_ind = sell_ind = ma_buy = ma_sell = 0
        if indicator_table:
            rows = indicator_table.find_all("tr")[1:]
            for row in rows:
                cols = row.find_all("td")
                if len(cols) >= 2:
                    signal = cols[1].text.strip().upper()
                    if "BUY" in signal:
                        buy_ind += 1
                    elif "SELL" in signal:
                        sell_ind += 1

        ma_table = soup.find_all("table", class_="overviewSummaryTbl")[-1]
        if ma_table:
            rows = ma_table.find_all("tr")[1:]
            for row in rows:
                cols = row.find_all("td")
                if len(cols) >= 2:
                    signal = cols[1].text.strip().upper()
                    if "BUY" in signal:
                        ma_buy += 1
                    elif "SELL" in signal:
                        ma_sell += 1

        ticker = yf.Ticker("^DJI")
        hist = ticker.history(period="2d", interval="5m")
        atr = hist["High"].sub(hist["Low"]).rolling(14).mean().iloc[-1]
        std = hist["Close"].rolling(14).std().iloc[-1]
        current_price = hist["Close"].iloc[-1]
        previous_price = hist["Close"].iloc[-2]
        direction = "UP" if current_price > previous_price else "DOWN"

        return {
            "summary_5m": summary_5m,
            "summary_15m": summary_15m,
            "buy_ind": buy_ind,
            "sell_ind": sell_ind,
            "ma_buy": ma_buy,
            "ma_sell": ma_sell,
            "atr": round(atr, 2),
            "std": round(std, 2),
            "direction": direction
        }
    except Exception as e:
        return {"error": str(e)}

def save_decision(action, confidence, reason):
    """שומר את החלטת המסחר בקובץ CSV ושולח הודעת טלגרם."""
    try:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        row = [now, action, confidence, reason]
        with open(SIGNALS_DIR / "us30_recommendation.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["time", "action", "confidence", "reason"])
            writer.writerow(row)

        with open(SIGNALS_DIR / "us30_history.csv", "a", encoding="utf-8") as hist:
            hist.write(json.dumps({"time": now, "action": action, "confidence": confidence, "reason": reason}, ensure_ascii=False) + "\n")

        send_telegram_message(action, confidence, reason)

    except Exception as e:
        print(f"שגיאה בשמירת החלטה: {e}")

def analyze_market():
    """מנתח את השוק ומחזיר נתונים טכניים על סמך אתר Investing."""
    import requests
    import yfinance as yf
    from bs4 import BeautifulSoup

    try:
        url = "https://www.investing.com/indices/us-30-technical"
        headers = {"User-Agent": "Mozilla/5.0"}
        page = requests.get(url, headers=headers)
        soup = BeautifulSoup(page.content, "html.parser")

        summary_table = soup.find("table", class_="technicalSummaryTbl")
        summary_5m = summary_15m = "NEUTRAL"
        if summary_table:
            rows = summary_table.find_all("tr")
            for row in rows[1:]:
                cols = row.find_all("td")
                if len(cols) >= 2:
                    tf = cols[0].text.strip().lower()
                    rec = cols[1].text.strip().upper()
                    if "5 minutes" in tf:
                        summary_5m = rec
                    elif "15 minutes" in tf:
                        summary_15m = rec

        indicator_table = soup.find("table", class_="overviewSummaryTbl")
        buy_ind = sell_ind = ma_buy = ma_sell = 0
        if indicator_table:
            rows = indicator_table.find_all("tr")[1:]
            for row in rows:
                cols = row.find_all("td")
                if len(cols) >= 2:
                    signal = cols[1].text.strip().upper()
                    if "BUY" in signal:
                        buy_ind += 1
                    elif "SELL" in signal:
                        sell_ind += 1

        ma_table = soup.find_all("table", class_="overviewSummaryTbl")[-1]
        if ma_table:
            rows = ma_table.find_all("tr")[1:]
            for row in rows:
                cols = row.find_all("td")
                if len(cols) >= 2:
                    signal = cols[1].text.strip().upper()
                    if "BUY" in signal:
                        ma_buy += 1
                    elif "SELL" in signal:
                        ma_sell += 1

        ticker = yf.Ticker("^DJI")
        hist = ticker.history(period="2d", interval="5m")
        atr = hist["High"].sub(hist["Low"]).rolling(14).mean().iloc[-1]
        std = hist["Close"].rolling(14).std().iloc[-1]
        current_price = hist["Close"].iloc[-1]
        previous_price = hist["Close"].iloc[-2]
        direction = "UP" if current_price > previous_price else "DOWN"

        return {
            "summary_5m": summary_5m,
            "summary_15m": summary_15m,
            "buy_ind": buy_ind,
            "sell_ind": sell_ind,
            "ma_buy": ma_buy,
            "ma_sell": ma_sell,
            "atr": round(atr, 2),
            "std": round(std, 2),
            "direction": direction
        }
    except Exception as e:
        return {"error": str(e)}

def decide_action(market_data):
    """מקבל החלטת מסחר על סמך נתוני השוק."""
    import openai
    if "error" in market_data:
        return "WAIT", 0, f"שגיאת שוק: {market_data['error']}"

    action = "WAIT"
    confidence = 0
    reason = ""

    if config.get("use_ai") and openai.api_key:
        try:
            messages = [{
                "role": "system",
                "content": "אתה עוזר מסחר חכם. החלף את החלטות השוק באנליזה קצרה והצע פעולה: BUY, SELL, או WAIT. ציין ביטחון באחוזים."
            }, {
                "role": "user",
                "content": json.dumps(market_data)
            }]

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=messages,
                temperature=0.3
            )
            content = response.choices[0].message.content
            if "BUY" in content:
                action = "BUY"
            elif "SELL" in content:
                action = "SELL"
            else:
                action = "WAIT"

            confidence = int(''.join(filter(str.isdigit, content.split("Confidence:")[-1]))[:2]) if "Confidence" in content else 70
            reason = content
        except Exception as e:
            reason = f"שגיאת AI: {str(e)}"
    else:
        if market_data["buy_ind"] >= config["indicator_min_buy"] and market_data["ma_buy"] >= config["ma_min_buy"]:
            action = "BUY"
            confidence = 80
            reason = "רוב האינדיקטורים והממוצעים נעים כלפי מעלה"
        elif market_data["sell_ind"] >= config["indicator_min_buy"] and market_data["ma_sell"] >= config["ma_min_buy"]:
            action = "SELL"
            confidence = 80
            reason = "רוב האינדיקטורים והממוצעים מצביעים על ירידה"

    if config.get("reverse_mode"):
        action = "SELL" if action == "BUY" else "BUY" if action == "SELL" else "WAIT"
        reason += " (REVERSED)"

    return action, confidence, reason

def save_decision(action, confidence, reason):
    """שומר את החלטת המסחר בקובץ CSV ושולח הודעת טלגרם."""
    import csv
    from datetime import datetime
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = [now, action, confidence, reason]
    with open(SIGNALS_DIR / "us30_recommendation.csv", "w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["time", "action", "confidence", "reason"])
        writer.writerow(row)

    with open(SIGNALS_DIR / "us30_history.csv", "a", encoding="utf-8") as hist:
        hist.write(json.dumps({"time": now, "action": action, "confidence": confidence, "reason": reason}, ensure_ascii=False) + "\n")

    send_telegram_message(action, confidence, reason)