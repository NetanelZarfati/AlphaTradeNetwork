import openai, json, time, threading, hashlib
from pathlib import Path
from datetime import datetime

# === נתיבי עבודה ===
BASE = Path("C:/AlphaTrade/שכתוב_אוטומטי_עם_GPT/scripts").parent
INPUT = BASE / "files_to_send"
CONFIG = BASE / "config"
OUTPUT = Path("C:/AlphaTrade/AlphaTradeA/command_files")
LOG = BASE / "fixer_log_loop.txt"
DATA_DIR = Path("C:/AlphaTrade/AlphaTradeA/data")
ROBOT_SOURCE_DIR = Path("C:/AlphaTrade/AlphaTradeA/robot_sources")
CACHE_FILE = BASE / "symbol_hashes.json"

# === לוג בסיסי ===
def log(msg):
    ts = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with open(LOG, "a", encoding="utf-8") as f: f.write(f"{ts} {msg}\n")
    print(f"{ts} {msg}")

# === טעינת נתוני OHLC ===
def load_ohlc(symbol):
    path = DATA_DIR / f"{symbol}_ohlc.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return None

# === טעינת קוד הרובוט ===
def load_robot_code():
    mq4_files = list(ROBOT_SOURCE_DIR.glob("*.mq4"))
    if not mq4_files:
        return ""
    return f"\n\n[קוד רובוט מצורף: {mq4_files[0].name}]\n" + mq4_files[0].read_text(encoding="utf-8")

# === הוראות משולבות + OHLC ===
def enrich_instructions(symbol):
    instructions_path = CONFIG / "instructions.txt"
    if not instructions_path.exists():
        log("[ERROR] instructions.txt not found")
        return ""
    instructions = instructions_path.read_text(encoding="utf-8")
    ohlc = load_ohlc(symbol)
    if ohlc:
        preview = json.dumps(ohlc, indent=2)[:1500]
        instructions += f"\n\n[נתוני OHLC עבור {symbol}:]\n{preview}"
    return instructions

# === טעינת Hash Cache ===
def load_hash_cache():
    if CACHE_FILE.exists():
        return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    return {}

# === שמירת Hash Cache ===
def save_hash_cache(cache):
    CACHE_FILE.write_text(json.dumps(cache, indent=2), encoding="utf-8")

# === הפעלת thread בודד לסימבול ===
def process_symbol(file, robot_code, config, hash_cache):
    symbol = file.stem.upper()
    code = file.read_text(encoding="utf-8")
    code_hash = hashlib.md5(code.encode("utf-8")).hexdigest()

    if hash_cache.get(symbol) == code_hash:
        log(f"[SKIP] ללא שינוי בקוד עבור {symbol}")
        return

    enriched = enrich_instructions(symbol)
    if not enriched:
        return

    try:
        response = openai.ChatCompletion.create(
            model=config.get("model", "gpt-4o"),
            messages=[
                {"role": "system", "content": "אתה עוזר תוכנה חכם שמשפר קוד מסחר תוך התאמה לנתונים חיים"},
                {"role": "user", "content": enriched + robot_code + "\n\n" + code}
            ],
            temperature=config.get("temperature", 0.3),
            max_tokens=config.get("max_tokens", 4096)
        )

        result = response.choices[0].message.content.strip()
        signal = json.loads(result)
        signal["timestamp"] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        signal["executed"] = False

        json_path = OUTPUT / f"{symbol}.json"
        json_path.write_text(json.dumps(signal, indent=2), encoding="utf-8")
        hash_cache[symbol] = code_hash
        log(f"[OK] עודכן: {symbol}.json")

    except Exception as e:
        log(f"[ERROR] {symbol} - {e}")

# === ריצה אינסופית בתהליכים מקבילים ===
def main_loop():
    config_path = CONFIG / "config.json"
    if not config_path.exists():
        log("[ERROR] config.json not found")
        return

    config = json.loads(config_path.read_text(encoding="utf-8"))
    robot_code = load_robot_code()
    hash_cache = load_hash_cache()

    while True:
        threads = []
        py_files = list(INPUT.glob("*.py"))

        for file in py_files:
            t = threading.Thread(target=process_symbol, args=(file, robot_code, config, hash_cache))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        save_hash_cache(hash_cache)
        time.sleep(60)

if __name__ == "__main__":
    main_loop()
