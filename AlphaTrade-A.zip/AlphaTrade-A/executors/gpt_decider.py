def decide_action(market_data):
    """מקבל החלטת מסחר על סמך נתוני השוק."""
    if "error" in market_data:
        return "WAIT", 0, f"שגיאת שוק: {market_data['error']}"

    action = "WAIT"
    confidence = 0
    reason = ""

    if config["use_ai"] and openai.api_key:
        try:
            messages = [{
                "role": "system",
                "content": "אתה עוזר מסחר חכם. החלף את החלטות השוק באנליזה קצרה והצע פעולה: BUY, SELL, או WAIT. ציין ביטחון באחוזים."
            }, {
                "role": "user",
                "content": json.dumps(market_data)
            }]

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=messages,
                temperature=0.3
            )
            content = response.choices[0].message.content
            if "BUY" in content:
                action = "BUY"
            elif "SELL" in content:
                action = "SELL"
            else:
                action = "WAIT"

            confidence = int(''.join(filter(str.isdigit, content.split("Confidence:")[-1]))[:2]) if "Confidence" in content else 70
            reason = content
        except Exception as e:
            reason = f"שגיאת AI: {str(e)}"
    else:
        if market_data["buy_ind"] >= config["indicator_min_buy"] and market_data["ma_buy"] >= config["ma_min_buy"]:
            action = "BUY"
            confidence = 80
            reason = "רוב האינדיקטורים והממוצעים נעים כלפי מעלה"
        elif market_data["sell_ind"] >= config["indicator_min_buy"] and market_data["ma_sell"] >= config["ma_min_buy"]:
            action = "SELL"
            confidence = 80
            reason = "רוב האינדיקטורים והממוצעים מצביעים על ירידה"

    if config["reverse_mode"]:
        action = "SELL" if action == "BUY" else "BUY" if action == "SELL" else "WAIT"
        reason += " (REVERSED)"

    return action, confidence, reason

def build_prompt(data, profile=None):
    """בונה פרומפט עבור GPT על בסיס נתוני שוק ופרופיל הצלחה."""
    if profile:
        return (
            "Based on the following market data and success profile, respond ONLY with one word: buy, sell, or wait.\n"
            f"Current RSI: {data['rsi']} | Successful RSI Avg: {profile['avg_rsi']}\n"
            f"Current Trend: {data['trend']} | Successful Trend Avg: {profile['avg_trend']}\n"
            f"Current Spike: {data['spike']} | Most Common Successful Spike: {profile['spike_mode']}\n"
            "What is the best trading action?"
        )
    else:
        return (
            "Based on the following market data, respond ONLY with one word: buy, sell, or wait.\n"
            f"RSI: {data['rsi']}\n"
            f"Trend: {data['trend']}\n"
            f"Spike: {data['spike']}\n"
            "What is the best trading action?"
        )

def query_gpt(prompt):
    """שולח פרומפט ל-GPT ומחזיר את התשובה."""
    try:
        if not openai.api_key:
            print("[INFO] GPT disabled. Returning 'wait'")
            return "wait"
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a financial trading decision AI."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content.strip().lower()
    except Exception as e:
        print(f"[ERROR] GPT query failed: {e}")
        return "wait"

def build_prompt(data, profile=None):
    if profile:
        return (
            "Based on the following market data and success profile, respond ONLY with one word: buy, sell, or wait.\n"
            f"Current RSI: {data['rsi']} | Successful RSI Avg: {profile['avg_rsi']}\n"
            f"Current Trend: {data['trend']} | Successful Trend Avg: {profile['avg_trend']}\n"
            f"Current Spike: {data['spike']} | Most Common Successful Spike: {profile['spike_mode']}\n"
            "What is the best trading action?"
        )
    else:
        return (
            "Based on the following market data, respond ONLY with one word: buy, sell, or wait.\n"
            f"RSI: {data['rsi']}\n"
            f"Trend: {data['trend']}\n"
            f"Spike: {data['spike']}\n"
            "What is the best trading action?"
        )

def query_gpt(prompt):
    try:
        import openai
        if not openai.api_key:
            print("[INFO] GPT disabled. Returning 'wait'")
            return "wait"
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a financial trading decision AI."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content.strip().lower()
    except Exception as e:
        print(f"[ERROR] GPT query failed: {e}")
        return "wait"