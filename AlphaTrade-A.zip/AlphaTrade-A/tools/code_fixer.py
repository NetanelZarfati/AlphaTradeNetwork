import openai, json, zipfile, shutil
from pathlib import Path
from datetime import datetime
import re

# === נתיבי עבודה ===
BASE = Path("C:/AlphaTrade/שכתוב_אוטומטי_עם_GPT/scripts").parent
INPUT = BASE / "files_to_send"
CONFIG = BASE / "config"
OUTPUT = Path("C:/AlphaTrade/AlphaTradeA/signals")
TMP = BASE / "tmp_extracted"
LOG = BASE / "fixer_log.txt"
ARCHIVE = BASE / "archive"

# === לוג בסיסי ===
def log(msg):
    ts = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with open(LOG, "a", encoding="utf-8") as f: f.write(f"{ts} {msg}\n")
    print(f"{ts} {msg}")

# === טעינת קונפיג והוראות ===
from AlphaTradeA.configs.config_api_keys import API_KEYS

def load_config():
    openai.api_key = API_KEYS["openai"]
    cfg = json.loads((CONFIG / "config.json").read_text(encoding="utf-8"))
    instr = (CONFIG / "instructions.txt").read_text(encoding="utf-8")
    return cfg, instr

# === חילוץ ZIP ===
def extract_zip(zip_path, target_dir):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(target_dir)
    log(f"[OK] ZIP נפתח: {zip_path.name}")

# === מציאת קבצי PY מתוך תיקייה ===
def find_python_files(folder):
    return list(folder.rglob("*.py"))

# === ניתוח מיקום לוגי לפי import ===
def infer_logical_path(code):
    matches = re.findall(r"from\s+([\w\.]+)\s+import|import\s+([\w\.]+)", code)
    for match in matches:
        parts = (match[0] or match[1]).split('.')
        if len(parts) >= 2:
            return Path(*parts).with_suffix(".py")
    return None

# === הסרת כפילויות ואיחוד קבצים חסרים ===
def deduplicate_and_merge(existing_code, new_code):
    if existing_code.strip() == new_code.strip():
        return existing_code  # אין שינוי
    if new_code in existing_code:
        return existing_code  # הקוד כבר קיים
    return existing_code.strip() + "\n\n" + new_code.strip()

# === שליחה ל-GPT עם תיאור מותאם אישית לכל קובץ ===
def send_to_gpt(code, file_description, instructions, config):
    try:
        if file_description == 'ForexFuryV41.mq4':
            code = (
                "// מבנה הגדרות רובוט קבוע\n"
                "// Username\n"
                "// TradeDirection\n"
                "// FixedLotSize\n"
                "// UseIncrementalLotSize\n"
                "// RiskPerTrade\n"
                "// StopLossPips\n"
                "// TakeProfitPips\n"
                "// MaxOrders\n"
                "// ReverseStrategy\n"
                "// OnlyRangeTrading\n"
                "// MaxSpreadPips\n"
                "// MaxSlippagePoints\n"
                "// UseDynamicRetrace\n"
                "// RetraceTriggerPips\n"
                "// RetraceExitPips\n"
                "// UseMartingale\n"
                "// LotMultiplier\n"
                "// MaxSteps\n"
                "// UseTrailingStop\n"
                "// TrailingStartPips\n"
                "// TrailingStepPips\n"
                "// TrailingStopPips\n"
                "// StartTime\n"
                "// StopTime\n"
                "// TradeOnMonday\n"
                "// TradeOnTuesday\n"
                "// TradeOnWednesday\n"
                "// TradeOnThursday\n"
                "// TradeOnFriday\n"
                "// DisplayPanel\n"
                "// PanelCorner\n"
                "// BGColor\n"
                "// TextColor\n"
                "// FontSize\n"
                "// OffsetX\n"
                "// OffsetY\n"
                "// UseTradingHours\n"
                "// CommandPrefix\n"
                "// CommentTag\n"
                "// BarsToExport\n"
                "// DisplayDebugPanel\n"
                "// DebugMode\n\n"
            ) + code
        full_prompt = f"{instructions}\n\n[קובץ: {file_description}]\n\n{code}"
        response = openai.ChatCompletion.create(
            model=config.get("model", "gpt-4o"),
            messages=[
                {"role": "system", "content": "אתה עוזר תוכנה חכם שמבצע שינויים בקוד לפי בקשה מפורשת של המשתמש. \n- תקן שגיאות סינטקס או לוגיקה אם יש. \n- סדר את הקוד לוגית. \n- הוסף קבצים חסרים אם נדרש. \n- הסר קוד כפול. \n- שמור על שמות משתנים ברורים. \n- שמור על הפונקציונליות המקורית. \n- אל תבצע פיצול לקבצים אלא אם נאמר במפורש. \n- אם יש קובץ קוד רובוט מצורף, ודא תיאום מלא בין הקוד הראשי לרובוט: שמות משתנים, מבנה, קלט/פלט, ופורמטים. כל פעולה שנעשית באחד – חייבת להיתמך על ידי השני."},
                {"role": "user", "content": full_prompt}
            ],
            temperature=config.get("temperature", 0.2),
            max_tokens=config.get("max_tokens", 8192)
        )
        return response.choices[0].message.content
    except Exception as e:
        log(f"[ERROR] GPT failed: {e}")
        return None

# === תהליך ראשי ===
def main():
    required_dirs = [INPUT, CONFIG, OUTPUT, TMP, ARCHIVE]
    for d in required_dirs:
        d.mkdir(parents=True, exist_ok=True)

    required_files = [
        CONFIG / "config.json",
        CONFIG / "instructions.txt",
        Path("C:/AlphaTrade/AlphaTradeA/configs/config_api_keys.py")
    ]
    missing = [str(f) for f in required_files if not f.exists()]
    if missing:
        log(f"[ERROR] קבצים חסרים: {missing}")
        return

    files = list(INPUT.glob("*.py")) + list(INPUT.glob("*.mq4")) + list(INPUT.glob("*.mq5")) + list(INPUT.glob("*.zip"))
    if not files:
        log("[ERROR] אין קבצים בתיקיית input")
        return

    config, instructions = load_config()

    for file in files:
        if file.suffix == ".zip":
            shutil.rmtree(TMP, ignore_errors=True)
            extract_zip(file, TMP)
            py_files = find_python_files(TMP) + list(TMP.rglob("*.mq4")) + list(TMP.rglob("*.mq5"))
            shutil.move(str(file), ARCHIVE / file.name)
        elif file.suffix in [".py", ".mq4", ".mq5"]:
            py_files = [file]
        else:
            log(f"[SKIP] פורמט לא נתמך: {file.name}")
            continue

        for py in py_files:
            code = py.read_text(encoding="utf-8")
            logical_path = infer_logical_path(code) if file.suffix == ".zip" else None
            relative_path = logical_path if logical_path else (py.relative_to(TMP) if file.suffix == ".zip" else py.name)
            subfolder = "fixed_code" if py.suffix == ".py" else "fixed_robots"
            out_path = OUTPUT / subfolder / relative_path
            out_path.parent.mkdir(parents=True, exist_ok=True)
            log(f"[INFO] שולח קובץ: {py.name} ל-GPT")
            fixed = send_to_gpt(code, py.name, instructions, config)
            if fixed:
                if out_path.exists():
                    existing = out_path.read_text(encoding="utf-8")
                    fixed = deduplicate_and_merge(existing, fixed)
                out_path.write_text(fixed.strip(), encoding="utf-8")
                log(f"[OK] תוצאה נשמרה: {out_path.relative_to(OUTPUT)}")
            else:
                log(f"[ERROR] GPT לא החזיר פלט עבור: {py.name}")

    log("[✓] תהליך הסתיים")

if __name__ == "__main__":
    main()